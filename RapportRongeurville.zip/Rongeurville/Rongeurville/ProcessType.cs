﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rongeurville
{
    public enum ProcessType
    {
        Map,
        Rat,
        Cat,
    }
}
