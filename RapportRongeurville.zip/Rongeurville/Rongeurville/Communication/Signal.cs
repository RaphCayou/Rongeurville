﻿using System;

namespace Rongeurville.Communication
{
    [Serializable]
    public abstract class Signal : Message
    {
    }
}