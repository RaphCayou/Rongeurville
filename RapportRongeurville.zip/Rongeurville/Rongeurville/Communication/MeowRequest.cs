﻿using System;

namespace Rongeurville.Communication
{
    [Serializable]
    public class MeowRequest : Request
    {
    }
}