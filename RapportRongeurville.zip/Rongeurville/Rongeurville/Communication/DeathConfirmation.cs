﻿using System;

namespace Rongeurville.Communication
{
    [Serializable]
    public class DeathConfirmation : Request
    {
    }
}