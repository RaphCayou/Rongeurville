﻿using System;
using System.Collections.Generic;

namespace Rongeurville.Communication
{
    [Serializable]
    public class KillSignal : Signal
    {
    }
}